// Minimal lightbox for screenshots. Links still work without JavaScript.
(function () {
  var links = document.querySelectorAll('a.zoom');
  if (!links.length) return;
  // On phones and tablets the link opens the full image in a new tab, where pinch-zoom works.
  if (!matchMedia('(min-width: 821px) and (hover: hover) and (pointer: fine)').matches) return;
  var box = document.createElement('div'), img = new Image(), last = null;
  box.className = 'lightbox'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true');
  box.setAttribute('aria-label', 'Full-size screenshot. Press Escape or click to close.'); box.tabIndex = -1;
  box.appendChild(img); document.body.appendChild(box);
  function close() {
    if (!box.classList.contains('open')) return;
    box.classList.remove('open'); document.documentElement.classList.remove('lb-lock');
    if (last) last.focus();
  }
  links.forEach(function (a) {
    a.addEventListener('click', function (e) {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
      e.preventDefault(); last = a;
      img.src = a.getAttribute('href'); img.alt = a.querySelector('img').alt;
      document.documentElement.classList.add('lb-lock');
      box.classList.add('open'); box.focus();
    });
  });
  box.addEventListener('click', close);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
})();

// Inline PDF viewer: only on wide screens with a built-in PDF viewer (class set in <head>).
(function () {
  if (!document.documentElement.classList.contains('pdf-ok')) return;
  document.querySelectorAll('iframe.pdf-frame[data-src]').forEach(function (f) { f.src = f.getAttribute('data-src'); });
})();
